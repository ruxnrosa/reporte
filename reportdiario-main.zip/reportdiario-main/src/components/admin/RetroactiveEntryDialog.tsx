import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { CalendarIcon, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import ImobiliariaTagInput, { imobToString } from "@/components/ImobiliariaTagInput";

interface BrokerProfile {
  id: string;
  name: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  brokers: BrokerProfile[];
  onSaved: () => void;
}

const RetroactiveEntryDialog = ({ open, onOpenChange, brokers, onSaved }: Props) => {
  const { toast } = useToast();
  const [brokerId, setBrokerId] = useState("");
  const [date, setDate] = useState<Date>();
  const [leads, setLeads] = useState("");
  const [fluxo, setFluxo] = useState("");
  const [visitas, setVisitas] = useState("");
  const [documentacao, setDocumentacao] = useState("");
  const [contratos, setContratos] = useState("");
  const [imobiliarias, setImobiliarias] = useState<string[]>([]);
  const [observacoes, setObservacoes] = useState("");
  const [loading, setLoading] = useState(false);
  const [conflictData, setConflictData] = useState<any>(null);
  const [showConflict, setShowConflict] = useState(false);

  const resetForm = () => {
    setBrokerId(""); setDate(undefined);
    setLeads(""); setFluxo(""); setVisitas("");
    setDocumentacao(""); setContratos(""); setImobiliarias([]); setObservacoes("");
  };

  const buildPayload = () => ({
    broker_id: brokerId,
    report_date: format(date!, "yyyy-MM-dd"),
    leads_recebidos: parseInt(leads) || 0,
    fluxo_realizado: parseInt(fluxo) || 0,
    visitas_realizadas: parseInt(visitas) || 0,
    documentacao_enviada: parseInt(documentacao) || 0,
    contrato_assinado: parseInt(contratos) || 0,
    imobiliaria: imobToString(imobiliarias),
    observacoes: observacoes || null,
  });

  const handleSubmit = async () => {
    if (!brokerId || !date) {
      toast({ title: "Campos obrigatórios", description: "Selecione corretor e data.", variant: "destructive" });
      return;
    }
    setLoading(true);

    const dateStr = format(date, "yyyy-MM-dd");
    const { data: existing } = await supabase
      .from("daily_reports")
      .select("*")
      .eq("broker_id", brokerId)
      .eq("report_date", dateStr)
      .maybeSingle();

    if (existing) {
      setConflictData(existing);
      setShowConflict(true);
      setLoading(false);
      return;
    }

    await saveNew();
  };

  const saveNew = async () => {
    setLoading(true);
    const payload = buildPayload();
    const { error } = await supabase.from("daily_reports").insert(payload);
    if (error) {
      toast({ title: "Erro", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Salvo!", description: "Lançamento registrado com sucesso." });
      resetForm();
      onOpenChange(false);
      onSaved();
    }
    setLoading(false);
  };

  const handleConflictAction = async (mode: "overwrite" | "sum") => {
    setShowConflict(false);
    setLoading(true);
    const payload = buildPayload();

    if (mode === "overwrite") {
      const { error } = await supabase.from("daily_reports").update({
        leads_recebidos: payload.leads_recebidos,
        fluxo_realizado: payload.fluxo_realizado,
        visitas_realizadas: payload.visitas_realizadas,
        documentacao_enviada: payload.documentacao_enviada,
        contrato_assinado: payload.contrato_assinado,
        observacoes: payload.observacoes,
      }).eq("id", conflictData.id);
      if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
      else {
        toast({ title: "Sobrescrito!", description: "Dados substituídos com sucesso." });
        resetForm(); onOpenChange(false); onSaved();
      }
    } else {
      const { error } = await supabase.from("daily_reports").update({
        leads_recebidos: conflictData.leads_recebidos + payload.leads_recebidos,
        fluxo_realizado: conflictData.fluxo_realizado + payload.fluxo_realizado,
        visitas_realizadas: conflictData.visitas_realizadas + payload.visitas_realizadas,
        documentacao_enviada: conflictData.documentacao_enviada + payload.documentacao_enviada,
        contrato_assinado: conflictData.contrato_assinado + payload.contrato_assinado,
        observacoes: payload.observacoes ? `${conflictData.observacoes || ""} | ${payload.observacoes}` : conflictData.observacoes,
      }).eq("id", conflictData.id);
      if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
      else {
        toast({ title: "Somado!", description: "Valores somados aos existentes." });
        resetForm(); onOpenChange(false); onSaved();
      }
    }
    setLoading(false);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Lançamento Retroativo</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Corretor</Label>
                <Select value={brokerId} onValueChange={setBrokerId}>
                  <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                  <SelectContent>
                    {brokers.map(b => (
                      <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Data</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn("w-full justify-start", !date && "text-muted-foreground")}>
                      <CalendarIcon className="h-4 w-4 mr-2" />
                      {date ? format(date, "dd/MM/yyyy") : "Selecione..."}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      locale={ptBR}
                      disabled={(d) => d > new Date()}
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label>Leads</Label>
                <Input type="number" min="0" placeholder="0" value={leads} onChange={e => setLeads(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Fluxo</Label>
                <Input type="number" min="0" placeholder="0" value={fluxo} onChange={e => setFluxo(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Visitas</Label>
                <Input type="number" min="0" placeholder="0" value={visitas} onChange={e => setVisitas(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Documentação</Label>
                <Input type="number" min="0" placeholder="0" value={documentacao} onChange={e => setDocumentacao(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Contratos</Label>
                <Input type="number" min="0" placeholder="0" value={contratos} onChange={e => setContratos(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Imobiliária</Label>
              <ImobiliariaTagInput
                value={imobiliarias}
                onChange={setImobiliarias}
                brokerName={brokers.find(b => b.id === brokerId)?.name}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Observações</Label>
              <Input placeholder="Notas opcionais..." value={observacoes} onChange={e => setObservacoes(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button onClick={handleSubmit} disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin mr-1" />} Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConflict} onOpenChange={setShowConflict}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Registro já existe</AlertDialogTitle>
            <AlertDialogDescription>
              Já existe um reporte para este corretor nesta data. Deseja sobrescrever os dados ou somar aos valores existentes?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleConflictAction("sum")} className="bg-accent hover:bg-accent/90">Somar</AlertDialogAction>
            <AlertDialogAction onClick={() => handleConflictAction("overwrite")} className="bg-destructive hover:bg-destructive/90">Sobrescrever</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default RetroactiveEntryDialog;
