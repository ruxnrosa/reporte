import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ClipboardCheck } from "lucide-react";

interface BrokerProfile {
  id: string;
  name: string;
}

interface Props {
  brokers: BrokerProfile[];
  todayReportBrokerIds: Set<string>;
}

const StatusEnvioSection = ({ brokers, todayReportBrokerIds }: Props) => {
  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2 pt-4 px-4">
        <div className="flex items-center gap-2">
          <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Status de Envio de Hoje</p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-3">
          {brokers.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum corretor ativo.</p>
          ) : (
            brokers.map((broker) => {
              const sent = todayReportBrokerIds.has(broker.id);
              return (
                <div key={broker.id} className="flex items-center gap-2 bg-muted/40 rounded-lg px-3 py-2">
                  <span className="text-sm font-medium">{broker.name}</span>
                  <Badge
                    variant={sent ? "default" : "destructive"}
                    className={sent ? "bg-[hsl(var(--success))] hover:bg-[hsl(var(--success))]/90" : ""}
                  >
                    {sent ? "Enviado" : "Pendente"}
                  </Badge>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StatusEnvioSection;
