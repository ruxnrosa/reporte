import { useState, useRef, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { X, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

const BROKER_DEFAULTS: Record<string, string[]> = {
  julia: ["Click"],
  luiz: ["Parceria"],
  erik: [
    "Servir", "Meu VGV", "Trip", "Oppen", "Reality", "Swell",
    "Connect", "Nova visão", "Turin", "Max One", "Playhouse",
    "Dimoveis", "VG imoveis", "Realiza",
  ],
};

interface ImobiliariaTagInputProps {
  value: string[];
  onChange: (value: string[]) => void;
  brokerName?: string | null;
}

const ImobiliariaTagInput = ({ value, onChange, brokerName }: ImobiliariaTagInputProps) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const triggerRef = useRef<HTMLDivElement>(null);

  const defaults = useMemo(() => {
    if (!brokerName) return [];
    const key = brokerName.toLowerCase().split(" ")[0];
    return BROKER_DEFAULTS[key] ?? [];
  }, [brokerName]);

  const available = useMemo(() => {
    return defaults.filter((d) => !value.includes(d));
  }, [defaults, value]);

  const filtered = useMemo(() => {
    if (!search.trim()) return available;
    const q = search.toLowerCase();
    return available.filter((s) => s.toLowerCase().includes(q));
  }, [available, search]);

  const allKnown = [...defaults, ...value];
  const isNewValue = search.trim() !== "" &&
    !allKnown.some((s) => s.toLowerCase() === search.trim().toLowerCase());

  const addTag = (tag: string) => {
    if (!value.includes(tag)) {
      onChange([...value, tag]);
    }
    setSearch("");
  };

  const removeTag = (tag: string) => {
    onChange(value.filter((v) => v !== tag));
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div
          ref={triggerRef}
          role="combobox"
          aria-expanded={open}
          className={cn(
            "flex min-h-10 w-full flex-wrap items-center gap-1.5 rounded-md border border-input bg-background px-3 py-2 text-sm cursor-pointer ring-offset-background",
            "hover:border-ring focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2",
            value.length === 0 && "text-muted-foreground"
          )}
          onClick={() => setOpen(true)}
        >
          {value.length === 0 && <span>Selecione imobiliárias...</span>}
          {value.map((tag) => (
            <Badge
              key={tag}
              variant="secondary"
              className="gap-1 rounded-full bg-secondary/60 text-secondary-foreground font-normal"
            >
              {tag}
              <X
                className="h-3 w-3 cursor-pointer hover:text-destructive"
                onClick={(e) => { e.stopPropagation(); removeTag(tag); }}
              />
            </Badge>
          ))}
        </div>
      </PopoverTrigger>
      <PopoverContent
        className="w-[--radix-popover-trigger-width] p-0"
        align="start"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <Command shouldFilter={false}>
          <CommandInput
            placeholder="Buscar ou adicionar..."
            value={search}
            onValueChange={setSearch}
          />
          <CommandList>
            <CommandEmpty className="py-2 text-center text-sm text-muted-foreground">
              {search.trim() ? "Nenhuma encontrada." : "Digite para buscar."}
            </CommandEmpty>
            {isNewValue && (
              <CommandGroup>
                <CommandItem
                  onSelect={() => addTag(search.trim())}
                  className="gap-2 text-primary cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  Adicionar "{search.trim()}"
                </CommandItem>
              </CommandGroup>
            )}
            {filtered.length > 0 && (
              <CommandGroup heading="Sugestões">
                {filtered.map((s) => (
                  <CommandItem key={s} onSelect={() => addTag(s)} className="cursor-pointer">
                    {s}
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default ImobiliariaTagInput;

/** Utility: convert between DB comma-separated string and string array */
export const imobToArray = (val: string | null): string[] => {
  if (!val) return [];
  return val.split(",").map((s) => s.trim()).filter(Boolean);
};

export const imobToString = (arr: string[]): string | null => {
  if (arr.length === 0) return null;
  return arr.join(", ");
};
