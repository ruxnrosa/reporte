import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Send, Loader2, LogOut, CalendarIcon } from "lucide-react";
import ImobiliariaTagInput, { imobToArray, imobToString } from "@/components/ImobiliariaTagInput";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";

const BrokerReportPage = () => {
  const { profileId, profileName, signOut } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [reportDate, setReportDate] = useState<Date>(new Date());
  const [form, setForm] = useState({
    leads_recebidos: "",
    fluxo_realizado: "",
    visitas_realizadas: "",
    documentacao_enviada: "",
    contrato_assinado: "",
    observacoes: "",
  });
  const [imobiliarias, setImobiliarias] = useState<string[]>([]);

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileId) return;

    setLoading(true);
    const { error } = await supabase.from("daily_reports").insert({
      broker_id: profileId,
      report_date: format(reportDate, "yyyy-MM-dd"),
      leads_recebidos: parseInt(form.leads_recebidos) || 0,
      fluxo_realizado: parseInt(form.fluxo_realizado) || 0,
      visitas_realizadas: parseInt(form.visitas_realizadas) || 0,
      documentacao_enviada: parseInt(form.documentacao_enviada) || 0,
      contrato_assinado: parseInt(form.contrato_assinado) || 0,
      imobiliaria: imobToString(imobiliarias),
      observacoes: form.observacoes,
    });

    if (error) {
      if (error.code === "23505") {
        toast({ title: "Reporte já enviado", description: "Você já enviou o reporte de hoje.", variant: "destructive" });
      } else {
        toast({ title: "Erro", description: error.message, variant: "destructive" });
      }
    } else {
      toast({ title: "Enviado!", description: "Seu reporte diário foi registrado com sucesso." });
      setForm({ leads_recebidos: "", fluxo_realizado: "", visitas_realizadas: "", documentacao_enviada: "", contrato_assinado: "", observacoes: "" });
      setImobiliarias([]);
    }
    setLoading(false);
  };

  const fields = [
    { key: "leads_recebidos", label: "Leads Recebidos" },
    { key: "fluxo_realizado", label: "Fluxo Realizado" },
    { key: "visitas_realizadas", label: "Visitas Realizadas" },
    { key: "documentacao_enviada", label: "Documentação Enviada" },
    { key: "contrato_assinado", label: "Contrato Assinado" },
  ];

  return (
    <div className="min-h-screen bg-ice">
      <header className="bg-primary shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold text-primary-foreground">Reporte Diário</h1>
            <p className="text-sm text-primary-foreground/70">{profileName}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={signOut} className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-navy-light">
            <LogOut className="h-4 w-4 mr-1" /> Sair
          </Button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8">
        <Card className="shadow-md border-0 animate-fade-in">
          <CardHeader>
            <CardTitle className="text-lg">Enviar Reporte de Hoje</CardTitle>
            <p className="text-sm text-muted-foreground">
              {new Date().toLocaleDateString("pt-BR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label>Data do Reporte</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn("w-full justify-start")}>
                      <CalendarIcon className="h-4 w-4 mr-2" />
                      {format(reportDate, "dd/MM/yyyy")}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={reportDate}
                      onSelect={(d) => d && setReportDate(d)}
                      locale={ptBR}
                      disabled={(d) => d > new Date()}
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {fields.map(({ key, label }) => (
                  <div key={key} className="space-y-1.5">
                    <Label htmlFor={key}>{label}</Label>
                    <Input
                      id={key}
                      type="number"
                      min="0"
                      placeholder="0"
                      value={(form as any)[key]}
                      onChange={(e) => handleChange(key, e.target.value)}
                    />
                  </div>
                ))}
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Imobiliária</Label>
                <ImobiliariaTagInput
                  value={imobiliarias}
                  onChange={setImobiliarias}
                  brokerName={profileName}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  placeholder="Notas ou comentários do dia..."
                  value={form.observacoes}
                  onChange={(e) => handleChange("observacoes", e.target.value)}
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-navy-light" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                Enviar Reporte
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default BrokerReportPage;
