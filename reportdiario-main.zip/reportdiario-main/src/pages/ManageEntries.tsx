import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { ArrowLeft, CalendarIcon, Pencil, Trash2, Search } from "lucide-react";
import ImobiliariaTagInput, { imobToArray, imobToString } from "@/components/ImobiliariaTagInput";

interface BrokerProfile {
  id: string;
  name: string;
}

interface ReportRow {
  id: string;
  broker_id: string;
  report_date: string;
  leads_recebidos: number;
  fluxo_realizado: number;
  visitas_realizadas: number;
  documentacao_enviada: number;
  contrato_assinado: number;
  imobiliaria: string | null;
  observacoes: string | null;
  broker_name?: string;
}

const ManageEntries = () => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const [brokers, setBrokers] = useState<BrokerProfile[]>([]);
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchName, setSearchName] = useState("");
  const [dateFrom, setDateFrom] = useState<Date | undefined>(undefined);
  const [dateTo, setDateTo] = useState<Date | undefined>(undefined);

  // Edit
  const [editReport, setEditReport] = useState<ReportRow | null>(null);
  const [editForm, setEditForm] = useState<Record<string, any>>({});

  // Delete
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const fetchBrokers = async () => {
    const { data } = await supabase.from("profiles").select("id, name").order("name");
    setBrokers(data ?? []);
  };

  const fetchReports = async () => {
    setLoading(true);
    let query = supabase
      .from("daily_reports")
      .select("*, profiles!daily_reports_broker_id_fkey(name)")
      .order("report_date", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(500);

    if (dateFrom) query = query.gte("report_date", format(dateFrom, "yyyy-MM-dd"));
    if (dateTo) query = query.lte("report_date", format(dateTo, "yyyy-MM-dd"));

    const { data } = await query;
    const rows: ReportRow[] = (data ?? []).map((r: any) => ({
      ...r,
      broker_name: r.profiles?.name ?? "—",
    }));
    setReports(rows);
    setLoading(false);
  };

  useEffect(() => { fetchBrokers(); }, []);
  useEffect(() => { fetchReports(); }, [dateFrom, dateTo]);

  const filtered = useMemo(() => {
    if (!searchName.trim()) return reports;
    const q = searchName.toLowerCase();
    return reports.filter(r => r.broker_name?.toLowerCase().includes(q));
  }, [reports, searchName]);

  // Edit handlers
  const openEdit = (r: ReportRow) => {
    setEditReport(r);
    setEditForm({
      broker_id: r.broker_id,
      report_date: r.report_date,
      leads_recebidos: r.leads_recebidos,
      fluxo_realizado: r.fluxo_realizado,
      visitas_realizadas: r.visitas_realizadas,
      documentacao_enviada: r.documentacao_enviada,
      contrato_assinado: r.contrato_assinado,
      imobiliarias: imobToArray(r.imobiliaria),
      observacoes: r.observacoes ?? "",
    });
  };

  const handleSave = async () => {
    if (!editReport) return;
    const { error } = await supabase
      .from("daily_reports")
      .update({
        broker_id: editForm.broker_id,
        report_date: editForm.report_date,
        leads_recebidos: Number(editForm.leads_recebidos) || 0,
        fluxo_realizado: Number(editForm.fluxo_realizado) || 0,
        visitas_realizadas: Number(editForm.visitas_realizadas) || 0,
        documentacao_enviada: Number(editForm.documentacao_enviada) || 0,
        contrato_assinado: Number(editForm.contrato_assinado) || 0,
        imobiliaria: imobToString(editForm.imobiliarias ?? []),
        observacoes: editForm.observacoes || null,
      })
      .eq("id", editReport.id);

    if (error) {
      toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Salvo com sucesso" });
      setEditReport(null);
      fetchReports();
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from("daily_reports").delete().eq("id", deleteId);
    if (error) {
      toast({ title: "Erro ao excluir", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Registro excluído" });
      fetchReports();
    }
    setDeleteId(null);
  };

  const cell = (val: any) => {
    if (val === 0 || val === "" || val === null || val === undefined) return <span className="text-muted-foreground">—</span>;
    return val;
  };

  const editDateObj = editForm.report_date ? new Date(editForm.report_date + "T12:00:00") : new Date();

  return (
    <div className="min-h-screen bg-ice">
      <header className="bg-primary shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/admin")} className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-navy-light">
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
          </Button>
          <h1 className="text-lg font-semibold text-primary-foreground">Gerenciar Lançamentos</h1>
        </div>
      </header>

      <main className="page-container space-y-6 animate-fade-in">
        {/* Filters */}
        <Card className="border-0 shadow-md">
          <CardContent className="pt-4 pb-4 flex flex-wrap items-end gap-4">
            <div className="flex-1 min-w-[200px]">
              <Label className="text-xs text-muted-foreground">Buscar Corretor</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Nome do corretor..."
                  value={searchName}
                  onChange={e => setSearchName(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Data Início</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-[150px] justify-start gap-2 text-sm">
                    <CalendarIcon className="h-4 w-4" />
                    {dateFrom ? format(dateFrom, "dd/MM/yyyy") : "Início"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} locale={ptBR} className="p-3 pointer-events-auto" />
                </PopoverContent>
              </Popover>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Data Fim</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-[150px] justify-start gap-2 text-sm">
                    <CalendarIcon className="h-4 w-4" />
                    {dateTo ? format(dateTo, "dd/MM/yyyy") : "Fim"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={dateTo} onSelect={setDateTo} locale={ptBR} className="p-3 pointer-events-auto" />
                </PopoverContent>
              </Popover>
            </div>
            {(dateFrom || dateTo || searchName) && (
              <Button variant="ghost" size="sm" onClick={() => { setDateFrom(undefined); setDateTo(undefined); setSearchName(""); }}>
                Limpar
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Table */}
        <Card className="border-0 shadow-md overflow-hidden">
          <CardHeader className="pb-2 pt-4 px-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              {filtered.length} registro{filtered.length !== 1 ? "s" : ""}
            </p>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="table-header hover:bg-navy-light">
                    <TableHead className="text-primary-foreground font-semibold whitespace-nowrap">Data</TableHead>
                    <TableHead className="text-primary-foreground font-semibold whitespace-nowrap">Corretor</TableHead>
                    <TableHead className="text-primary-foreground font-semibold text-center">Leads</TableHead>
                    <TableHead className="text-primary-foreground font-semibold text-center">Fluxo</TableHead>
                    <TableHead className="text-primary-foreground font-semibold text-center">Visitas</TableHead>
                    <TableHead className="text-primary-foreground font-semibold text-center">Docs</TableHead>
                    <TableHead className="text-primary-foreground font-semibold text-center">Contratos</TableHead>
                    <TableHead className="text-primary-foreground font-semibold whitespace-nowrap">Imob</TableHead>
                    <TableHead className="text-primary-foreground font-semibold whitespace-nowrap">Observação</TableHead>
                    <TableHead className="text-primary-foreground font-semibold text-center">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">Carregando...</TableCell></TableRow>
                  ) : filtered.length === 0 ? (
                    <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">Nenhum registro encontrado.</TableCell></TableRow>
                  ) : (
                    filtered.map((r, i) => (
                      <TableRow key={r.id} className={i % 2 === 0 ? "" : "bg-muted/30"}>
                        <TableCell className="text-sm whitespace-nowrap">{format(new Date(r.report_date + "T12:00:00"), "dd/MM/yyyy")}</TableCell>
                        <TableCell className="text-sm font-medium">{r.broker_name}</TableCell>
                        <TableCell className="text-sm text-center">{cell(r.leads_recebidos)}</TableCell>
                        <TableCell className="text-sm text-center">{cell(r.fluxo_realizado)}</TableCell>
                        <TableCell className="text-sm text-center">{cell(r.visitas_realizadas)}</TableCell>
                        <TableCell className="text-sm text-center">{cell(r.documentacao_enviada)}</TableCell>
                        <TableCell className="text-sm text-center">{cell(r.contrato_assinado)}</TableCell>
                        <TableCell className="text-sm max-w-[120px] truncate">{cell(r.imobiliaria)}</TableCell>
                        <TableCell className="text-sm max-w-[150px] truncate">{cell(r.observacoes)}</TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(r)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteId(r.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Edit Dialog */}
      <Dialog open={!!editReport} onOpenChange={(o) => !o && setEditReport(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Editar Lançamento</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Corretor</Label>
              <Select value={editForm.broker_id} onValueChange={v => setEditForm(f => ({ ...f, broker_id: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {brokers.map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Data</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <CalendarIcon className="h-4 w-4" />
                    {format(editDateObj, "dd/MM/yyyy")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={editDateObj}
                    onSelect={d => d && setEditForm(f => ({ ...f, report_date: format(d, "yyyy-MM-dd") }))}
                    locale={ptBR}
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { key: "leads_recebidos", label: "Leads" },
                { key: "fluxo_realizado", label: "Fluxo" },
                { key: "visitas_realizadas", label: "Visitas" },
                { key: "documentacao_enviada", label: "Documentação" },
                { key: "contrato_assinado", label: "Contratos" },
              ].map(f => (
                <div key={f.key}>
                  <Label>{f.label}</Label>
                  <Input
                    type="number"
                    min={0}
                    value={editForm[f.key] ?? 0}
                    onChange={e => setEditForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  />
                </div>
              ))}
            </div>
            <div>
              <Label>Imobiliária</Label>
              <ImobiliariaTagInput
                value={editForm.imobiliarias ?? []}
                onChange={(v) => setEditForm(f => ({ ...f, imobiliarias: v }))}
                brokerName={brokers.find(b => b.id === editForm.broker_id)?.name}
              />
            </div>
            <div>
              <Label>Observações</Label>
              <Textarea value={editForm.observacoes ?? ""} onChange={e => setEditForm(f => ({ ...f, observacoes: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditReport(null)}>Cancelar</Button>
            <Button onClick={handleSave}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>Tem certeza que deseja excluir este registro? Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ManageEntries;
