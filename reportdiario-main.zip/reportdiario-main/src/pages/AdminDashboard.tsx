import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { CalendarIcon, Users, FileText, TrendingUp, LogOut, UserPlus, BarChart3, PlusCircle, Download, ClipboardList } from "lucide-react";
import * as XLSX from "xlsx";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import StatusEnvioSection from "@/components/admin/StatusEnvioSection";
import RetroactiveEntryDialog from "@/components/admin/RetroactiveEntryDialog";

interface BrokerProfile {
  id: string;
  name: string;
  is_active: boolean;
  user_id: string;
}

interface DailyReport {
  id: string;
  broker_id: string;
  report_date: string;
  leads_recebidos: number;
  fluxo_realizado: number;
  visitas_realizadas: number;
  documentacao_enviada: number;
  contrato_assinado: number;
  observacoes: string;
}

const columns = [
  { key: "leads_recebidos", label: "Leads" },
  { key: "fluxo_realizado", label: "Fluxo" },
  { key: "visitas_realizadas", label: "Visitas" },
  { key: "documentacao_enviada", label: "Docs" },
  { key: "contrato_assinado", label: "Contratos" },
];

const AdminDashboard = () => {
  const { toast } = useToast();
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [allBrokers, setAllBrokers] = useState<BrokerProfile[]>([]);
  const [dailyReports, setDailyReports] = useState<DailyReport[]>([]);
  const [monthlyReports, setMonthlyReports] = useState<DailyReport[]>([]);
  const [todayReports, setTodayReports] = useState<DailyReport[]>([]);
  const [showRetroactive, setShowRetroactive] = useState(false);

  const [adminUserIds, setAdminUserIds] = useState<Set<string>>(new Set());

  const activeBrokers = allBrokers.filter(b => b.is_active);

  // Brokers that appear in monthly table: active ones + inactive ones that have data
  const monthlyBrokerIds = new Set(monthlyReports.map(r => r.broker_id));
  const monthlyBrokers = allBrokers.filter(b => b.is_active || monthlyBrokerIds.has(b.id));

  const fetchBrokers = async () => {
    const { data } = await supabase.from("profiles").select("id, name, is_active, user_id").order("name");
    setAllBrokers(data ?? []);
  };

  const fetchAdminUserIds = async () => {
    const { data } = await supabase.from("user_roles").select("user_id").eq("role", "admin");
    setAdminUserIds(new Set((data ?? []).map(r => r.user_id)));
  };

  const fetchDailyReports = async () => {
    const dateStr = format(selectedDate, "yyyy-MM-dd");
    const { data } = await supabase.from("daily_reports").select("*").eq("report_date", dateStr);
    setDailyReports(data ?? []);
  };

  const fetchMonthlyReports = async () => {
    const ms = format(startOfMonth(selectedDate), "yyyy-MM-dd");
    const me = format(endOfMonth(selectedDate), "yyyy-MM-dd");
    const { data } = await supabase.from("daily_reports").select("*").gte("report_date", ms).lte("report_date", me);
    setMonthlyReports(data ?? []);
  };

  const fetchTodayReports = async () => {
    const today = format(new Date(), "yyyy-MM-dd");
    const { data } = await supabase.from("daily_reports").select("*").eq("report_date", today);
    setTodayReports(data ?? []);
  };

  useEffect(() => { fetchBrokers(); fetchTodayReports(); fetchAdminUserIds(); }, []);
  useEffect(() => { fetchDailyReports(); fetchMonthlyReports(); }, [selectedDate]);

  const refreshAll = () => { fetchDailyReports(); fetchMonthlyReports(); fetchTodayReports(); };

  const getReportForBroker = (brokerId: string, reports: DailyReport[]) =>
    reports.filter(r => r.broker_id === brokerId);

  const getAccumulated = (brokerId: string) => {
    const reports = getReportForBroker(brokerId, monthlyReports);
    return {
      leads_recebidos: reports.reduce((s, r) => s + r.leads_recebidos, 0),
      fluxo_realizado: reports.reduce((s, r) => s + r.fluxo_realizado, 0),
      visitas_realizadas: reports.reduce((s, r) => s + r.visitas_realizadas, 0),
      documentacao_enviada: reports.reduce((s, r) => s + r.documentacao_enviada, 0),
      contrato_assinado: reports.reduce((s, r) => s + r.contrato_assinado, 0),
    };
  };

  const totalMonthLeads = monthlyReports.reduce((s, r) => s + r.leads_recebidos, 0);
  const totalMonthVisitas = monthlyReports.reduce((s, r) => s + r.visitas_realizadas, 0);
  const totalMonthContratos = monthlyReports.reduce((s, r) => s + r.contrato_assinado, 0);

  const cell = (val: any) => {
    if (val === 0 || val === "" || val === null || val === undefined) return <span className="text-muted-foreground">—</span>;
    return val;
  };

  const todayReportBrokerIds = new Set(todayReports.map(r => r.broker_id));

  const handleExport = async () => {
    const { data: reports } = await supabase
      .from("daily_reports")
      .select("*, profiles!daily_reports_broker_id_fkey(name)")
      .order("report_date", { ascending: false });

    if (!reports || reports.length === 0) {
      toast({ title: "Sem dados", description: "Nenhum registro encontrado para exportar.", variant: "destructive" });
      return;
    }

    const rows = reports.map((r: any) => ({
      "Data": r.report_date,
      "Corretor": r.profiles?.name ?? "—",
      "Imobiliária": r.imobiliaria ?? "",
      "Leads": r.leads_recebidos,
      "Fluxo": r.fluxo_realizado,
      "Visitas": r.visitas_realizadas,
      "Documentação": r.documentacao_enviada,
      "Contrato": r.contrato_assinado,
      "Observações": r.observacoes ?? "",
      "Criado em": r.created_at,
    }));

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Relatório");
    XLSX.writeFile(wb, `relatorio_completo_${format(new Date(), "yyyy-MM-dd")}.xlsx`);
  };

  return (
    <div className="min-h-screen bg-ice">
      <header className="bg-primary shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BarChart3 className="h-6 w-6 text-primary-foreground" />
            <h1 className="text-lg font-semibold text-primary-foreground">Painel Administrativo</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate("/admin/team")} className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-navy-light">
              <UserPlus className="h-4 w-4 mr-1" /> Equipe
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut} className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-navy-light">
              <LogOut className="h-4 w-4 mr-1" /> Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="page-container space-y-6 animate-fade-in">
        {/* Action Buttons (Top) */}
        <div className="flex items-center gap-3 flex-wrap">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="justify-start gap-2">
                <CalendarIcon className="h-4 w-4" />
                {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar mode="single" selected={selectedDate} onSelect={(d) => d && setSelectedDate(d)} locale={ptBR} className={cn("p-3 pointer-events-auto")} />
            </PopoverContent>
          </Popover>
          <Button variant="outline" onClick={() => setShowRetroactive(true)} className="gap-2">
            <PlusCircle className="h-4 w-4" /> Lançamento Manual
          </Button>
          <Button variant="outline" onClick={() => navigate("/admin/entries")} className="gap-2">
            <ClipboardList className="h-4 w-4" /> Gerenciar Lançamentos
          </Button>
          <Button variant="outline" onClick={() => navigate("/admin/team")} className="gap-2">
            <UserPlus className="h-4 w-4" /> Gestão de Corretores
          </Button>
          <Button variant="outline" onClick={handleExport} className="gap-2">
            <Download className="h-4 w-4" /> Exportar Excel
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="stat-card">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                <TrendingUp className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Leads do Mês</p>
                <p className="text-2xl font-bold">{totalMonthLeads}</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[hsl(var(--warning))]/10">
                <Users className="h-5 w-5 text-[hsl(var(--warning))]" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Visitas do Mês</p>
                <p className="text-2xl font-bold">{totalMonthVisitas}</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[hsl(var(--success))]/10">
                <FileText className="h-5 w-5 text-[hsl(var(--success))]" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Contratos do Mês</p>
                <p className="text-2xl font-bold">{totalMonthContratos}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tables Side by Side */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily Table */}
          <Card className="border-0 shadow-md overflow-hidden">
            <CardHeader className="pb-2 pt-4 px-4">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Performance Hoje</p>
              <p className="text-sm text-foreground/70">{format(selectedDate, "dd/MM/yyyy")}</p>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="table-header hover:bg-navy-light">
                      <TableHead className="text-primary-foreground font-semibold sticky left-0 bg-[hsl(var(--table-header))] z-10 min-w-[100px]">EV</TableHead>
                      {columns.map(c => (
                        <TableHead key={c.key} className="text-primary-foreground font-semibold text-center px-2 whitespace-nowrap">{c.label}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activeBrokers.length === 0 ? (
                      <TableRow><TableCell colSpan={columns.length + 1} className="text-center text-muted-foreground py-8">Nenhum corretor ativo.</TableCell></TableRow>
                    ) : (
                      activeBrokers.map((broker, i) => {
                        const report = getReportForBroker(broker.id, dailyReports)[0];
                        return (
                          <TableRow key={broker.id} className={i % 2 === 0 ? "" : "bg-muted/30"}>
                            <TableCell className="font-medium sticky left-0 bg-card z-10 text-sm">{broker.name}</TableCell>
                            {columns.map(c => (
                              <TableCell key={c.key} className="text-center px-2 text-sm">{cell(report ? (report as any)[c.key] : null)}</TableCell>
                            ))}
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Table */}
          <Card className="border-0 shadow-md overflow-hidden border-l-2 border-l-accent/20">
            <CardHeader className="pb-2 pt-4 px-4 bg-[hsl(var(--table-stripe))]">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Consolidado do Mês</p>
              <p className="text-sm text-foreground/70">{format(selectedDate, "MMMM 'de' yyyy", { locale: ptBR })}</p>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="table-header hover:bg-navy-light">
                      <TableHead className="text-primary-foreground font-semibold sticky left-0 bg-[hsl(var(--table-header))] z-10 min-w-[100px]">EV</TableHead>
                      {columns.map(c => (
                        <TableHead key={c.key} className="text-primary-foreground font-semibold text-center px-2 whitespace-nowrap">{c.label}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {monthlyBrokers.length === 0 ? (
                      <TableRow><TableCell colSpan={columns.length} className="text-center text-muted-foreground py-8">Nenhum dado.</TableCell></TableRow>
                    ) : (
                      monthlyBrokers.map((broker, i) => {
                        const acc = getAccumulated(broker.id);
                        return (
                          <TableRow key={broker.id} className={cn(i % 2 === 0 ? "bg-[hsl(var(--table-stripe))]" : "bg-card", !broker.is_active && "opacity-60")}>
                            <TableCell className="font-medium sticky left-0 bg-inherit z-10 text-sm">
                              {broker.name}
                              {!broker.is_active && <span className="text-xs text-muted-foreground ml-1">(inativo)</span>}
                            </TableCell>
                            <TableCell className="text-center px-2 text-sm">{cell(acc.leads_recebidos)}</TableCell>
                            <TableCell className="text-center px-2 text-sm">{cell(acc.fluxo_realizado)}</TableCell>
                            <TableCell className="text-center px-2 text-sm">{cell(acc.visitas_realizadas)}</TableCell>
                            <TableCell className="text-center px-2 text-sm">{cell(acc.documentacao_enviada)}</TableCell>
                            <TableCell className="text-center px-2 text-sm">{cell(acc.contrato_assinado)}</TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Status de Envio - only corretores (exclude admins) */}
        <StatusEnvioSection brokers={activeBrokers.filter(b => !adminUserIds.has(b.user_id))} todayReportBrokerIds={todayReportBrokerIds} />
      </main>

      {/* Retroactive Dialog */}
      <RetroactiveEntryDialog
        open={showRetroactive}
        onOpenChange={setShowRetroactive}
        brokers={allBrokers}
        onSaved={refreshAll}
      />
    </div>
  );
};

export default AdminDashboard;
