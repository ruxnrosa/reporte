import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Loader2, Trash2, UserPlus, Pencil } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Broker {
  id: string;
  user_id: string;
  name: string;
  email: string;
  is_active: boolean;
  role?: string;
}

const TeamManagement = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [brokers, setBrokers] = useState<Broker[]>([]);
  const [loading, setLoading] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState<string>("corretor");

  // Edit state
  const [editBroker, setEditBroker] = useState<Broker | null>(null);
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editPassword, setEditPassword] = useState("");
  const [editRole, setEditRole] = useState<string>("corretor");
  const [editLoading, setEditLoading] = useState(false);

  const fetchBrokers = async () => {
    const { data: profiles } = await supabase.from("profiles").select("id, user_id, name, email, is_active").order("name");
    if (!profiles) { setBrokers([]); return; }

    const { data: roles } = await supabase.from("user_roles").select("user_id, role");
    const roleMap = new Map((roles ?? []).map(r => [r.user_id, r.role]));

    setBrokers(profiles.map(p => ({ ...p, role: roleMap.get(p.user_id) || "corretor" })));
  };

  useEffect(() => { fetchBrokers(); }, []);

  const handleAddBroker = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim() || !newPassword.trim()) return;
    setLoading(true);

    const { data, error: fnError } = await supabase.functions.invoke("create-broker", {
      body: { email: newEmail, password: newPassword, name: newName, role: newRole },
    });

    if (fnError || data?.error) {
      toast({ title: "Erro", description: data?.error || fnError?.message, variant: "destructive" });
    } else {
      toast({ title: "Cadastrado!", description: `${newName} foi adicionado com sucesso.` });
      setNewName(""); setNewEmail(""); setNewPassword(""); setNewRole("corretor");
      fetchBrokers();
    }
    setLoading(false);
  };

  const handleToggleActive = async (broker: Broker) => {
    const { error } = await supabase.functions.invoke("create-broker", {
      body: { action: "update", profile_id: broker.id, user_id: broker.user_id, is_active: !broker.is_active },
    });
    if (error) {
      toast({ title: "Erro", description: "Não foi possível alterar o status.", variant: "destructive" });
    } else {
      fetchBrokers();
    }
  };

  const openEdit = (broker: Broker) => {
    setEditBroker(broker);
    setEditName(broker.name);
    setEditEmail(broker.email);
    setEditPassword("");
    setEditRole(broker.role || "corretor");
  };

  const handleEditSave = async () => {
    if (!editBroker) return;
    setEditLoading(true);

    const body: Record<string, any> = {
      action: "update",
      profile_id: editBroker.id,
      user_id: editBroker.user_id,
      name: editName,
      email: editEmail,
      role: editRole,
    };
    if (editPassword.trim()) body.password = editPassword;

    const { data, error } = await supabase.functions.invoke("create-broker", { body });
    if (error || data?.error) {
      toast({ title: "Erro", description: data?.error || error?.message, variant: "destructive" });
    } else {
      toast({ title: "Atualizado!", description: `${editName} foi atualizado.` });
      setEditBroker(null);
      fetchBrokers();
    }
    setEditLoading(false);
  };

  const handleRemoveBroker = async (broker: Broker) => {
    const { data, error } = await supabase.functions.invoke("create-broker", {
      body: { action: "delete", user_id: broker.user_id },
    });
    if (error || data?.error) {
      toast({ title: "Erro", description: data?.error || error?.message, variant: "destructive" });
    } else {
      toast({ title: "Removido", description: `${broker.name} foi removido.` });
      fetchBrokers();
    }
  };

  return (
    <div className="min-h-screen bg-ice">
      <header className="bg-primary shadow-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/admin")} className="text-primary-foreground hover:bg-navy-light">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-primary-foreground">Gestão da Equipe</h1>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8 space-y-6 animate-fade-in">
        {/* Add Form */}
        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <UserPlus className="h-5 w-5" /> Cadastrar Novo Usuário
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddBroker} className="grid grid-cols-1 sm:grid-cols-5 gap-4 items-end">
              <div className="space-y-1.5">
                <Label>Nome</Label>
                <Input placeholder="Nome completo" value={newName} onChange={(e) => setNewName(e.target.value)} required />
              </div>
              <div className="space-y-1.5">
                <Label>E-mail</Label>
                <Input type="email" placeholder="email@exemplo.com" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} required />
              </div>
              <div className="space-y-1.5">
                <Label>Senha</Label>
                <Input type="password" placeholder="Mín. 6 caracteres" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={6} />
              </div>
              <div className="space-y-1.5">
                <Label>Função</Label>
                <Select value={newRole} onValueChange={setNewRole}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="corretor">Corretor</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="bg-primary hover:bg-navy-light" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <UserPlus className="h-4 w-4 mr-1" />}
                Cadastrar
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* List */}
        <Card className="border-0 shadow-md overflow-hidden">
          <CardHeader>
            <CardTitle className="text-base">Equipe</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="table-header hover:bg-navy-light">
                  <TableHead className="text-primary-foreground font-semibold">Nome</TableHead>
                  <TableHead className="text-primary-foreground font-semibold">E-mail</TableHead>
                  <TableHead className="text-primary-foreground font-semibold text-center">Função</TableHead>
                  <TableHead className="text-primary-foreground font-semibold text-center">Ativo</TableHead>
                  <TableHead className="text-primary-foreground font-semibold text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {brokers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      Nenhum usuário cadastrado.
                    </TableCell>
                  </TableRow>
                ) : (
                  brokers.map((broker, i) => (
                    <TableRow key={broker.id} className={i % 2 === 0 ? "" : "bg-muted/30"}>
                      <TableCell className="font-medium">{broker.name}</TableCell>
                      <TableCell className="text-muted-foreground">{broker.email}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant={broker.role === "admin" ? "default" : "secondary"}>
                          {broker.role === "admin" ? "Admin" : "Corretor"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch checked={broker.is_active} onCheckedChange={() => handleToggleActive(broker)} />
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(broker)} className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remover {broker.name}?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Esta ação é irreversível e apagará o usuário e todos os dados associados.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleRemoveBroker(broker)} className="bg-destructive hover:bg-destructive/90">Remover</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </main>

      {/* Edit Dialog */}
      <Dialog open={!!editBroker} onOpenChange={(open) => !open && setEditBroker(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Usuário</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Nome</Label>
              <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>E-mail</Label>
              <Input type="email" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Nova Senha (deixe vazio para manter)</Label>
              <Input type="password" placeholder="••••••" value={editPassword} onChange={(e) => setEditPassword(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Função</Label>
              <Select value={editRole} onValueChange={setEditRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="corretor">Corretor</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditBroker(null)}>Cancelar</Button>
            <Button onClick={handleEditSave} disabled={editLoading}>
              {editLoading && <Loader2 className="h-4 w-4 animate-spin mr-1" />} Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TeamManagement;
