
-- Add is_active field to profiles
ALTER TABLE public.profiles ADD COLUMN is_active boolean NOT NULL DEFAULT true;

-- Add unique constraint on daily_reports to prevent duplicates per broker per date
ALTER TABLE public.daily_reports ADD CONSTRAINT daily_reports_broker_date_unique UNIQUE (broker_id, report_date);
